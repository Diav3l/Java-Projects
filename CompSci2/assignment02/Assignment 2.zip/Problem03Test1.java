import java.util.Scanner;

public class Problem03Test1 {
    public static void main(String[] args){
        Problem03part1 B2S = new Problem03part1();
        Scanner in = new Scanner(System.in);

        System.out.print("Enter a binary number and display its decimal equivalent : ");
        String binaryString = in.nextLine();
        B2S.bin2Dec(binaryString);
        in.close();
    }
}
